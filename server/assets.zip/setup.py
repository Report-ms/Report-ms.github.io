import requests
import pathlib

def replaceInFile(path, fromText, toText):
    with open(path, 'r', encoding=\"utf-8\") as file :
        filedata = file.read()
    filedata = filedata.replace(fromText, toText)
    with open(path, 'w', encoding=\"utf-8\") as file:
        file.write(filedata)


ip = requests.get('https://builds.report.ms/api/get-my-ip').json().ip
folder = pathlib.Path().resolve()
appFolder = folder + '/app'
localManipulatorFolder = folder + '/local-manipulator'

newPassword = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(12))

replaceInFile(appFolder + '/appsettings.json', '<%InsertIpHere%>', ip)
replaceInFile(appFolder + '/appsettings.json', '<%InsertPasswordHere%>', newPassword)
replaceInFile(appFolder + '/appsettings.json', '<%InsertFileStoragePath%>', folder + '/fileStorage')

replaceInFile(localManipulatorFolder + '/appsettings.json', '<%InsertPasswordHere%>', newPassword)
replaceInFile(localManipulatorFolder + '/appsettings.json', '<%InsertScriptsPath%>', folder + '/scripts')

replaceInFile(localManipulatorFolder + '/local-manipulator.service', '<%LocalManipulatorFolder%>', localManipulatorFolder)


