Проект: Report.ms Application Server
Описание: ������ ���������� ��� �������� Report.ms

Это сборка для Linux.

Требования к серверу:
- Linux или одна из его модификаций. https://www.linuxfoundation.org/
- PostgreSQL 9.6 и выше. https://www.postgresql.org

Модицифируйте `appsetting.json`:
- Задайте доступ к базе Postgresql в секции `ConnectionStrings`->`DataAccessPostgreSqlProvider`
- Задайте Путь к хранилищу файлов в секции `FileStoragePath`

Запустите App.exe и откройте `http://localhost:5000/` в браузере.


Для запуска в Docker выполните:
docker-compose up

Откройте в браузере http://localhost:5000